#!/bin/bash

$PYTHON -m pip install --no-deps --ignore-installed .
